if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DataTestSon_Params {
    num?: number;
    count?: number;
}
//子页面
//导出，被其他文件的父组件使用
export class DataTestSon extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__num = new ObservedPropertySimplePU(0, this, "num");
        this.__count = new SynchedPropertySimpleTwoWayPU(params.count, this, "count");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DataTestSon_Params) {
        if (params.num !== undefined) {
            this.num = params.num;
        }
    }
    updateStateVars(params: DataTestSon_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__num.purgeDependencyOnElmtId(rmElmtId);
        this.__count.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__num.aboutToBeDeleted();
        this.__count.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __num: ObservedPropertySimplePU<number>;
    get num() {
        return this.__num.get();
    }
    set num(newValue: number) {
        this.__num.set(newValue);
    }
    private __count: SynchedPropertySimpleTwoWayPU<number>;
    get count() {
        return this.__count.get();
    }
    set count(newValue: number) {
        this.__count.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('子组件' + this.count.toString());
            Text.debugLine("entry/src/main/ets/pages/DataTestSon.ets(9:5)", "entry");
            Text.onClick(() => {
                this.count++;
            });
        }, Text);
        Text.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
