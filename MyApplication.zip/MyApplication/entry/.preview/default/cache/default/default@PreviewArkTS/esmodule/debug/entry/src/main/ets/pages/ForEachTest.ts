if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface ForEachTest_Params {
    arr?: number[];
    arr1?: string[];
    arr2?: arrItem[];
}
interface arrItem {
    name: string;
    age: number;
    phone?: number;
}
class ForEachTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__arr = new ObservedPropertyObjectPU([1, 2, 3, 4], this, "arr");
        this.__arr1 = new ObservedPropertyObjectPU(['11', '22']
        //第一步：第一数据源
        , this, "arr1");
        this.__arr2 = new ObservedPropertyObjectPU([
            { name: '1', age: 2 },
            { name: '2', age: 2 }
        ], this, "arr2");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: ForEachTest_Params) {
        if (params.arr !== undefined) {
            this.arr = params.arr;
        }
        if (params.arr1 !== undefined) {
            this.arr1 = params.arr1;
        }
        if (params.arr2 !== undefined) {
            this.arr2 = params.arr2;
        }
    }
    updateStateVars(params: ForEachTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__arr.purgeDependencyOnElmtId(rmElmtId);
        this.__arr1.purgeDependencyOnElmtId(rmElmtId);
        this.__arr2.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__arr.aboutToBeDeleted();
        this.__arr1.aboutToBeDeleted();
        this.__arr2.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __arr: ObservedPropertyObjectPU<number[]>;
    get arr() {
        return this.__arr.get();
    }
    set arr(newValue: number[]) {
        this.__arr.set(newValue);
    }
    private __arr1: ObservedPropertyObjectPU<string[]>;
    get arr1() {
        return this.__arr1.get();
    }
    set arr1(newValue: string[]) {
        this.__arr1.set(newValue);
    }
    //第一步：第一数据源
    private __arr2: ObservedPropertyObjectPU<arrItem[]>;
    get arr2() {
        return this.__arr2.get();
    }
    set arr2(newValue: arrItem[]) {
        this.__arr2.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/ForEachTest.ets(19:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //ui循环生成函数
            //ForEach(数据源，循环函数箭头函数(每一项：每一项的类型，下标：数据类型)=>{})
            ForEach.create();
            const forEachItemGenFunction = (_item, index: number) => {
                const item = _item;
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    //被循环UI内容
                    Text.create('我叫' + item.name + '年龄为' + item.age);
                    Text.debugLine("entry/src/main/ets/pages/ForEachTest.ets(24:11)", "entry");
                }, Text);
                //被循环UI内容
                Text.pop();
            };
            this.forEachUpdateFunction(elmtId, this.arr2, forEachItemGenFunction, undefined, true, false);
        }, ForEach);
        //ui循环生成函数
        //ForEach(数据源，循环函数箭头函数(每一项：每一项的类型，下标：数据类型)=>{})
        ForEach.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "ForEachTest";
    }
}
registerNamedRoute(() => new ForEachTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/ForEachTest", pageFullPath: "entry/src/main/ets/pages/ForEachTest", integratedHsp: "false", moduleType: "followWithHap" });
