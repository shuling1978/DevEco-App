if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface a07Swiper_Params {
}
class a07Swiper extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: a07Swiper_Params) {
    }
    updateStateVars(params: a07Swiper_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Swiper.create();
            Swiper.debugLine("entry/src/main/ets/pages/a07Swiper.ets(7:5)", "entry");
            Swiper.height('20%');
            Swiper.loop(true);
            Swiper.autoPlay(true);
        }, Swiper);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('1');
            Text.debugLine("entry/src/main/ets/pages/a07Swiper.ets(8:7)", "entry");
            Text.width('100%');
            Text.height('100%');
            Text.backgroundColor(Color.Green);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('1');
            Text.debugLine("entry/src/main/ets/pages/a07Swiper.ets(12:8)", "entry");
            Text.width('100%');
            Text.height('100%');
            Text.backgroundColor(Color.Red);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('1');
            Text.debugLine("entry/src/main/ets/pages/a07Swiper.ets(16:8)", "entry");
            Text.width('100%');
            Text.height('100%');
            Text.backgroundColor(Color.Orange);
        }, Text);
        Text.pop();
        Swiper.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "a07Swiper";
    }
}
registerNamedRoute(() => new a07Swiper(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a07Swiper", pageFullPath: "entry/src/main/ets/pages/a07Swiper", integratedHsp: "false", moduleType: "followWithHap" });
