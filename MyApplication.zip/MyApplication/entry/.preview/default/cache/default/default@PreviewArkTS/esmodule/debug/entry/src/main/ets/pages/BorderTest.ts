if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface BorderTest_Params {
}
class BorderTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: BorderTest_Params) {
    }
    updateStateVars(params: BorderTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/BorderTest.ets(6:4)", "entry");
            Text.width(80);
            Text.height(80);
            Text.border({ width: 10, color: Color.Blue });
            Text.borderRadius(10);
            Text.borderStyle(BorderStyle.Solid);
        }, Text);
        Text.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "BorderTest";
    }
}
registerNamedRoute(() => new BorderTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/BorderTest", pageFullPath: "entry/src/main/ets/pages/BorderTest", integratedHsp: "false", moduleType: "followWithHap" });
