if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface a08ScrollTest_Params {
}
class a08ScrollTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: a08ScrollTest_Params) {
    }
    updateStateVars(params: a08ScrollTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //滑动组件
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Scroll.create();
            Scroll.debugLine("entry/src/main/ets/pages/a08ScrollTest.ets(7:5)", "entry");
            Scroll.scrollBarWidth(50);
        }, Scroll);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/a08ScrollTest.ets(8:7)", "entry");
            Text.height(2000);
            Text.width(300);
            Text.border({ width: 2 });
        }, Text);
        Text.pop();
        Scroll.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "a08ScrollTest";
    }
}
registerNamedRoute(() => new a08ScrollTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a08ScrollTest", pageFullPath: "entry/src/main/ets/pages/a08ScrollTest", integratedHsp: "false", moduleType: "followWithHap" });
