if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface arinz_Params {
}
class arinz extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: arinz_Params) {
    }
    updateStateVars(params: arinz_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Flex.create({ direction: FlexDirection.RowReverse,
                justifyContent: FlexAlign.SpaceBetween,
                alignContent: FlexAlign.SpaceBetween
            });
            Flex.debugLine("entry/src/main/ets/pages/arinz.ets(6:5)", "entry");
            Flex.width('100%');
            Flex.height('100%');
            Flex.border({ width: 5 });
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('1');
            Text.debugLine("entry/src/main/ets/pages/arinz.ets(10:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 2 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('2');
            Text.debugLine("entry/src/main/ets/pages/arinz.ets(11:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 2 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('3');
            Text.debugLine("entry/src/main/ets/pages/arinz.ets(12:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 2 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('4');
            Text.debugLine("entry/src/main/ets/pages/arinz.ets(13:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 2 });
        }, Text);
        Text.pop();
        Flex.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "arinz";
    }
}
registerNamedRoute(() => new arinz(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/arinz", pageFullPath: "entry/src/main/ets/pages/arinz", integratedHsp: "false", moduleType: "followWithHap" });
