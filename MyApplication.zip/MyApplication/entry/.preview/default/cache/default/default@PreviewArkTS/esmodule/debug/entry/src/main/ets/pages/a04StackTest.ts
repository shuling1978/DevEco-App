if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface a04StackTest_Params {
}
class a04StackTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: a04StackTest_Params) {
    }
    updateStateVars(params: a04StackTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //层叠布局
            Stack.create({ alignContent: Alignment.TopEnd });
            Stack.debugLine("entry/src/main/ets/pages/a04StackTest.ets(6:5)", "entry");
            //层叠布局
            Stack.width('100%');
            //层叠布局
            Stack.height('100%');
            //层叠布局
            Stack.border({ width: 5 });
        }, Stack);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('剩余3s 跳过');
            Text.debugLine("entry/src/main/ets/pages/a04StackTest.ets(7:7)", "entry");
            Text.width(100);
            Text.height(100);
            Text.backgroundColor(Color.Green);
            Text.zIndex(999);
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //默认越往后，层级越高
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/a04StackTest.ets(14:7)", "entry");
            //默认越往后，层级越高
            Text.width('100%');
            //默认越往后，层级越高
            Text.height('100%');
            //默认越往后，层级越高
            Text.backgroundColor(Color.Red);
        }, Text);
        //默认越往后，层级越高
        Text.pop();
        //层叠布局
        Stack.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "a04StackTest";
    }
}
registerNamedRoute(() => new a04StackTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a04StackTest", pageFullPath: "entry/src/main/ets/pages/a04StackTest", integratedHsp: "false", moduleType: "followWithHap" });
