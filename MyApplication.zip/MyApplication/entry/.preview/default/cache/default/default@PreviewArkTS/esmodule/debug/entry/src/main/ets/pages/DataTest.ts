if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface DataTest_Params {
    num?: number;
}
import { DataTestSon } from "@normalized:N&&&entry/src/main/ets/pages/DataTestSon&";
class DataTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__num = new ObservedPropertySimplePU(0, this, "num");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: DataTest_Params) {
        if (params.num !== undefined) {
            this.num = params.num;
        }
    }
    updateStateVars(params: DataTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__num.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__num.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __num: ObservedPropertySimplePU<number>;
    get num() {
        return this.__num.get();
    }
    set num(newValue: number) {
        this.__num.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/DataTest.ets(9:7)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //使用子组件，并传值
            //父的改变会影响子，子的改变不会影响父
            Text.create('父组件' + this.num.toString());
            Text.debugLine("entry/src/main/ets/pages/DataTest.ets(12:9)", "entry");
            //使用子组件，并传值
            //父的改变会影响子，子的改变不会影响父
            Text.onClick(() => {
                this.num++;
            });
        }, Text);
        //使用子组件，并传值
        //父的改变会影响子，子的改变不会影响父
        Text.pop();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new DataTestSon(this, { count: this.__num }, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/DataTest.ets", line: 16, col: 9 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {
                            count: this.num
                        };
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "DataTestSon" });
        }
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "DataTest";
    }
}
registerNamedRoute(() => new DataTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/DataTest", pageFullPath: "entry/src/main/ets/pages/DataTest", integratedHsp: "false", moduleType: "followWithHap" });
