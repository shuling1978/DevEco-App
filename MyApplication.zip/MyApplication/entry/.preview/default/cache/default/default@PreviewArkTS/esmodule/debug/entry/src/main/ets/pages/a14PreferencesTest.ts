if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface a14PreferencesTest_Params {
}
import preferences from "@ohos:data.preferences";
import { Content as Content } from "@ohos:arkui.node";
//第二步 定义一个全局状态
let dataPreferences: preferences.Preferences | null = null;
class a14PreferencesTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: a14PreferencesTest_Params) {
    }
    updateStateVars(params: a14PreferencesTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //第三步 获取实例 需要在页面构建前
    //页面获取上下文 getContext
    aboutToAppear(): void {
        dataPreferences = preferences.getPreferencesSync(getContext(Content), { name: 'myStore' });
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/a14PreferencesTest.ets(19:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('存储学校 school(键名) name(值)为吉林大学 ');
            Button.debugLine("entry/src/main/ets/pages/a14PreferencesTest.ets(20:7)", "entry");
            Button.onClick(() => {
                //第四步使用 通过实例调用内置方法
                dataPreferences?.putSync('school', '吉林大学');
                //持久化存储 这两个基本上联用
                dataPreferences?.flush();
            });
        }, Button);
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('读取学校 school(键名) 的值 ');
            Button.debugLine("entry/src/main/ets/pages/a14PreferencesTest.ets(27:7)", "entry");
            Button.onClick(() => {
                let str = dataPreferences?.getSync('school', '没有哦');
                console.log('吉大 值为' + dataPreferences?.getSync('school', '没有哦') + str);
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "a14PreferencesTest";
    }
}
registerNamedRoute(() => new a14PreferencesTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a14PreferencesTest", pageFullPath: "entry/src/main/ets/pages/a14PreferencesTest", integratedHsp: "false", moduleType: "followWithHap" });
