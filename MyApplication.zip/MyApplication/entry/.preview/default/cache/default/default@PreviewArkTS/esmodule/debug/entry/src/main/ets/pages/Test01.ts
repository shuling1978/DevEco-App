if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Test01_Params {
}
//枚举类型
enum Color {
    White = "1",
    Black = "2"
}
class Test01 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Test01_Params) {
    }
    updateStateVars(params: Test01_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Test01";
    }
}
registerNamedRoute(() => new Test01(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Test01", pageFullPath: "entry/src/main/ets/pages/Test01", integratedHsp: "false", moduleType: "followWithHap" });
