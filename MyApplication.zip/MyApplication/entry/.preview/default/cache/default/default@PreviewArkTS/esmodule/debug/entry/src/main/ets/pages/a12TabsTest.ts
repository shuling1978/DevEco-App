if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface TabsTest_Params {
}
import { a11ListTest } from "@normalized:N&&&entry/src/main/ets/pages/a11ListTest&";
class TabsTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: TabsTest_Params) {
    }
    updateStateVars(params: TabsTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //tabs导航
            Tabs.create({ barPosition: BarPosition.End });
            Tabs.debugLine("entry/src/main/ets/pages/a12TabsTest.ets(8:5)", "entry");
            //tabs导航
            Tabs.onChange((index: number) => {
                console.log('吉大' + index);
            });
            //tabs导航
            Tabs.scrollable(false);
            //tabs导航
            Tabs.barWidth('100%');
            //tabs导航
            Tabs.barBackgroundColor(Color.Pink);
        }, Tabs);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                {
                    this.observeComponentCreation2((elmtId, isInitialRender) => {
                        if (isInitialRender) {
                            let componentCall = new 
                            // Text('1')
                            a11ListTest(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/a12TabsTest.ets", line: 11, col: 9 });
                            ViewPU.create(componentCall);
                            let paramsLambda = () => {
                                return {};
                            };
                            componentCall.paramsGenerator_ = paramsLambda;
                        }
                        else {
                            this.updateStateVarsOfChildByElmtId(elmtId, {});
                        }
                    }, { name: "a11ListTest" });
                }
            });
            TabContent.tabBar('首页');
            TabContent.debugLine("entry/src/main/ets/pages/a12TabsTest.ets(9:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    //搜索组件
                    Search.create({ value: '', placeholder: '请输入' });
                    Search.debugLine("entry/src/main/ets/pages/a12TabsTest.ets(18:9)", "entry");
                    //搜索组件
                    Search.searchButton('搜索');
                    //搜索组件
                    Search.onSubmit((value) => {
                        console.log('吉大 onSubmit ' + value);
                    });
                    //搜索组件
                    Search.onChange((value) => {
                        console.log('吉大 onChange ' + value);
                    });
                }, Search);
                //搜索组件
                Search.pop();
            });
            TabContent.tabBar('首页');
            TabContent.debugLine("entry/src/main/ets/pages/a12TabsTest.ets(16:7)", "entry");
        }, TabContent);
        TabContent.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TabContent.create(() => {
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('3');
                    Text.debugLine("entry/src/main/ets/pages/a12TabsTest.ets(30:9)", "entry");
                }, Text);
                Text.pop();
            });
            TabContent.tabBar('首页');
            TabContent.debugLine("entry/src/main/ets/pages/a12TabsTest.ets(29:7)", "entry");
        }, TabContent);
        TabContent.pop();
        //tabs导航
        Tabs.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "TabsTest";
    }
}
registerNamedRoute(() => new TabsTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a12TabsTest", pageFullPath: "entry/src/main/ets/pages/a12TabsTest", integratedHsp: "false", moduleType: "followWithHap" });
