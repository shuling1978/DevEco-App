if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface BuilderTest_Params {
}
class BuilderTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: BuilderTest_Params) {
    }
    updateStateVars(params: BuilderTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //定义builder
    textBuilder(title: string, parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //只能写UI内容
            Text.create(title);
            Text.debugLine("entry/src/main/ets/pages/BuilderTest.ets(8:5)", "entry");
        }, Text);
        //只能写UI内容
        Text.pop();
    }
    textBuilder1(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //只能写UI内容
            Text.create('Builder内容1');
            Text.debugLine("entry/src/main/ets/pages/BuilderTest.ets(11:5)", "entry");
        }, Text);
        //只能写UI内容
        Text.pop();
    }
    textBuilder2(parent = null) {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //只能写UI内容
            Text.create('Builder内容2');
            Text.debugLine("entry/src/main/ets/pages/BuilderTest.ets(14:5)", "entry");
        }, Text);
        //只能写UI内容
        Text.pop();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //列布局
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/BuilderTest.ets(20:5)", "entry");
        }, Column);
        this.textBuilder.bind(this)('miao');
        this.textBuilder1.bind(this)();
        this.textBuilder2.bind(this)();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //按钮 多态样式
            Button.createWithLabel('按钮');
            Button.debugLine("entry/src/main/ets/pages/BuilderTest.ets(26:7)", "entry");
            ViewStackProcessor.visualState("focused");
            //按钮 多态样式
            Button.backgroundColor(Color.Pink);
            ViewStackProcessor.visualState("pressed");
            //按钮 多态样式
            Button.backgroundColor(Color.Red);
            //按钮 多态样式
            Button.width(200);
            ViewStackProcessor.visualState("normal");
            //按钮 多态样式
            Button.backgroundColor(Color.Blue);
            ViewStackProcessor.visualState();
        }, Button);
        //按钮 多态样式
        Button.pop();
        //列布局
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "BuilderTest";
    }
}
registerNamedRoute(() => new BuilderTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/BuilderTest", pageFullPath: "entry/src/main/ets/pages/BuilderTest", integratedHsp: "false", moduleType: "followWithHap" });
