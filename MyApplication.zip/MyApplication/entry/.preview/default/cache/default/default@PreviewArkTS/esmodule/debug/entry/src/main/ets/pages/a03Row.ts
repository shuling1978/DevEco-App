if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface a03row_Params {
}
class a03row extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: a03row_Params) {
    }
    updateStateVars(params: a03row_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //行布局
            //主轴为横向 默认侧轴居中
            Row.create({ space: 50 });
            Row.debugLine("entry/src/main/ets/pages/a03Row.ets(9:5)", "entry");
            //行布局
            //主轴为横向 默认侧轴居中
            Row.width('100%');
            //行布局
            //主轴为横向 默认侧轴居中
            Row.height('100%');
            //行布局
            //主轴为横向 默认侧轴居中
            Row.border({ width: 5 });
            //行布局
            //主轴为横向 默认侧轴居中
            Row.justifyContent(FlexAlign.SpaceBetween);
            //行布局
            //主轴为横向 默认侧轴居中
            Row.alignItems(VerticalAlign.Bottom);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/a03Row.ets(10:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/a03Row.ets(11:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/a03Row.ets(12:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Blank.create();
            Blank.debugLine("entry/src/main/ets/pages/a03Row.ets(13:7)", "entry");
        }, Blank);
        Blank.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/a03Row.ets(14:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 10 });
        }, Text);
        Text.pop();
        //行布局
        //主轴为横向 默认侧轴居中
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "a03row";
    }
}
registerNamedRoute(() => new a03row(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a03Row", pageFullPath: "entry/src/main/ets/pages/a03Row", integratedHsp: "false", moduleType: "followWithHap" });
