if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface a10RouterTest_Params {
}
import router from "@ohos:router";
class a10RouterTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: a10RouterTest_Params) {
    }
    updateStateVars(params: a10RouterTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/a10RouterTest.ets(8:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('跳转');
            Button.debugLine("entry/src/main/ets/pages/a10RouterTest.ets(9:7)", "entry");
            Button.onClick(() => {
                //url代表目标地址
                //跳转后想返回
                router.pushUrl({ url: "pages/Index" });
                //跳转后不想返回
                //router.replaceUrl({url:"pages/Index"})
                //返回上一页 和 pushUrl联用
                //router.back()
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "a10RouterTest";
    }
}
registerNamedRoute(() => new a10RouterTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a10RouterTest", pageFullPath: "entry/src/main/ets/pages/a10RouterTest", integratedHsp: "false", moduleType: "followWithHap" });
