if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface a05FlexTest_Params {
}
class a05FlexTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: a05FlexTest_Params) {
    }
    updateStateVars(params: a05FlexTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //改变主轴:direction 换行:Wrap
            // 调整主轴:justifyContent 调整侧轴:alignContent
            Flex.create({ direction: FlexDirection.RowReverse, wrap: FlexWrap.Wrap,
                justifyContent: FlexAlign.SpaceBetween,
                alignContent: FlexAlign.End
            });
            Flex.debugLine("entry/src/main/ets/pages/a05FlexTest.ets(8:5)", "entry");
            //改变主轴:direction 换行:Wrap
            // 调整主轴:justifyContent 调整侧轴:alignContent
            Flex.width('100%');
            //改变主轴:direction 换行:Wrap
            // 调整主轴:justifyContent 调整侧轴:alignContent
            Flex.height('100%');
            //改变主轴:direction 换行:Wrap
            // 调整主轴:justifyContent 调整侧轴:alignContent
            Flex.border({ width: 5 });
        }, Flex);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('1');
            Text.debugLine("entry/src/main/ets/pages/a05FlexTest.ets(12:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 2 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('2');
            Text.debugLine("entry/src/main/ets/pages/a05FlexTest.ets(13:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 2 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('3');
            Text.debugLine("entry/src/main/ets/pages/a05FlexTest.ets(14:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 2 });
        }, Text);
        Text.pop();
        //改变主轴:direction 换行:Wrap
        // 调整主轴:justifyContent 调整侧轴:alignContent
        Flex.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "a05FlexTest";
    }
}
registerNamedRoute(() => new a05FlexTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a05FlexTest", pageFullPath: "entry/src/main/ets/pages/a05FlexTest", integratedHsp: "false", moduleType: "followWithHap" });
