if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface a09CommonTest_Params {
    num?: number;
}
class a09CommonTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__num = new ObservedPropertySimplePU(0, this, "num");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: a09CommonTest_Params) {
        if (params.num !== undefined) {
            this.num = params.num;
        }
    }
    updateStateVars(params: a09CommonTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__num.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__num.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __num: ObservedPropertySimplePU<number>;
    get num() {
        return this.__num.get();
    }
    set num(newValue: number) {
        this.__num.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/a10CommonTest.ets(12:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('下拉选择');
            Text.debugLine("entry/src/main/ets/pages/a10CommonTest.ets(13:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Select.create([
                { value: '111', icon: { "id": 0, "type": 30000, params: ['图片1.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" } },
                { value: '222' },
                { value: '333' },
            ]);
            Select.debugLine("entry/src/main/ets/pages/a10CommonTest.ets(14:7)", "entry");
            Select.value('444');
            Select.onSelect((value) => {
                console.log('吉大 ' + value);
            });
        }, Select);
        Select.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Span text');
            Text.debugLine("entry/src/main/ets/pages/a10CommonTest.ets(25:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //可以作为容器组件使用 只能包裹Span
            Text.create('111222');
            Text.debugLine("entry/src/main/ets/pages/a10CommonTest.ets(27:7)", "entry");
        }, Text);
        //可以作为容器组件使用 只能包裹Span
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/a10CommonTest.ets(28:7)", "entry");
        }, Text);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('111');
            Span.debugLine("entry/src/main/ets/pages/a10CommonTest.ets(29:9)", "entry");
        }, Span);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('222');
            Span.debugLine("entry/src/main/ets/pages/a10CommonTest.ets(30:9)", "entry");
            Span.fontColor(Color.Blue);
        }, Span);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('输入框');
            Text.debugLine("entry/src/main/ets/pages/a10CommonTest.ets(34:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextInput.create({ placeholder: '默认提示信息', text: '默认可选中信息' });
            TextInput.debugLine("entry/src/main/ets/pages/a10CommonTest.ets(35:7)", "entry");
            TextInput.onChange((value: string) => {
                console.log('吉大' + value);
            });
        }, TextInput);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            TextArea.create();
            TextArea.debugLine("entry/src/main/ets/pages/a10CommonTest.ets(39:7)", "entry");
        }, TextArea);
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "a09CommonTest";
    }
}
registerNamedRoute(() => new a09CommonTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a10CommonTest", pageFullPath: "entry/src/main/ets/pages/a10CommonTest", integratedHsp: "false", moduleType: "followWithHap" });
