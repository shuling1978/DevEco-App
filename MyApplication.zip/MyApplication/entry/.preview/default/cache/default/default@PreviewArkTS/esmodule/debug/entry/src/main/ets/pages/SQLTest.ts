if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface SQLTest_Params {
    rdbStore?: relationalStore.RdbStore | null;
}
import relationalStore from "@ohos:data.relationalStore";
import { Content as Content } from "@ohos:arkui.node";
// 第二步：定义全局数据库对象
// let rdbStore: relationalStore.RdbStore | null = null
//配置信息
//包含数据库名称，包含安全级别
const store: relationalStore.StoreConfig = {
    name: 'jidaDB',
    securityLevel: relationalStore.SecurityLevel.S3
};
//建表
const sqlUser = 'create table if not exists USER(ID integer primary key autoincrement,name text not null ,age integer)';
class SQLTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.rdbStore = null;
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: SQLTest_Params) {
        if (params.rdbStore !== undefined) {
            this.rdbStore = params.rdbStore;
        }
    }
    updateStateVars(params: SQLTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private rdbStore: relationalStore.RdbStore | null;
    //页面构建前获取实例
    aboutToAppear(): void {
        this.getJidaDB();
    }
    async getJidaDB() {
        this.rdbStore = await relationalStore.getRdbStore(getContext(Content), store);
        this.rdbStore.executeSql(sqlUser);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/SQLTest.ets(32:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Button.createWithLabel('存储');
            Button.debugLine("entry/src/main/ets/pages/SQLTest.ets(33:7)", "entry");
            Button.onClick(() => {
                let num = this.rdbStore?.insertSync('USER', { name: '吉林大学', age: 20 }) || 0;
                if (num > 0) {
                    AlertDialog.show({ message: '插入陈宫了' });
                }
                else {
                    AlertDialog.show({ message: '插入失败了' });
                }
            });
        }, Button);
        Button.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "SQLTest";
    }
}
registerNamedRoute(() => new SQLTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/SQLTest", pageFullPath: "entry/src/main/ets/pages/SQLTest", integratedHsp: "false", moduleType: "followWithHap" });
