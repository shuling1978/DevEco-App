if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface a09CommonTest_Params {
    num?: number;
}
import JSON from "@ohos:util.json";
class a09CommonTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__num = new ObservedPropertySimplePU(0, this, "num");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: a09CommonTest_Params) {
        if (params.num !== undefined) {
            this.num = params.num;
        }
    }
    updateStateVars(params: a09CommonTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__num.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__num.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __num: ObservedPropertySimplePU<number>;
    get num() {
        return this.__num.get();
    }
    set num(newValue: number) {
        this.__num.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(12:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            /************************按钮**********************************/
            Button.createWithLabel('按钮' + this.num);
            Button.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(14:7)", "entry");
            /************************按钮**********************************/
            Button.type(ButtonType.Normal);
            /************************按钮**********************************/
            Button.fontSize(20);
            /************************按钮**********************************/
            Button.width(300);
            /************************按钮**********************************/
            Button.height(80);
            /************************按钮**********************************/
            Button.borderRadius(20);
            /************************按钮**********************************/
            Button.border({ width: 10 });
            /************************按钮**********************************/
            Button.onClick(() => {
                this.num++;
            });
        }, Button);
        /************************按钮**********************************/
        Button.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            /*************************************多选框******************************************/
            Checkbox.create();
            Checkbox.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(30:7)", "entry");
            /*************************************多选框******************************************/
            Checkbox.onChange((flag) => {
                //打印 控制台
                console.log('吉大' + flag);
            });
            /*************************************多选框******************************************/
            Checkbox.select(true);
            /*************************************多选框******************************************/
            Checkbox.selectedColor(Color.Green);
        }, Checkbox);
        /*************************************多选框******************************************/
        Checkbox.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Checkbox.create();
            Checkbox.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(38:7)", "entry");
        }, Checkbox);
        Checkbox.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Checkbox.create();
            Checkbox.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(39:7)", "entry");
        }, Checkbox);
        Checkbox.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('群组');
            Text.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(41:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //群组
            CheckboxGroup.create({ group: 'check' });
            CheckboxGroup.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(43:7)", "entry");
            //群组
            CheckboxGroup.onChange((selected) => {
                //解析对象
                console.log('吉大' + JSON.stringify(selected));
            });
        }, CheckboxGroup);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //分组 一般组件里面写 {}
            //属性不写{}
            Checkbox.create({ group: 'check', name: '我是1' });
            Checkbox.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(46:9)", "entry");
        }, Checkbox);
        //分组 一般组件里面写 {}
        //属性不写{}
        Checkbox.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Checkbox.create({ group: 'check', name: '我是2' });
            Checkbox.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(47:9)", "entry");
        }, Checkbox);
        Checkbox.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Checkbox.create({ group: 'check', name: '我是3' });
            Checkbox.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(48:9)", "entry");
        }, Checkbox);
        Checkbox.pop();
        //群组
        CheckboxGroup.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            /*************************************数据看板******************************************/
            Text.create('数据看板');
            Text.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(56:7)", "entry");
        }, Text);
        /*************************************数据看板******************************************/
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //也是需要一个数据源
            DataPanel.create({ values: [10, 10, 10, 10, 30], max: 100, type: DataPanelType.Line });
            DataPanel.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(58:7)", "entry");
            //也是需要一个数据源
            DataPanel.width(300);
            //也是需要一个数据源
            DataPanel.height(20);
        }, DataPanel);
        //也是需要一个数据源
        DataPanel.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('图片');
            Text.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(63:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create({ "id": 0, "type": 30000, params: ['图片1.png'], "bundleName": "com.example.myapplication", "moduleName": "entry" });
            Image.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(64:7)", "entry");
            Image.width(50);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Image.create('https://tse1-mm.cn.bing.net/th/id/OIP-C.f7VK7a9VPVVcAfQWa2cuUwHaI8?w=182&h=220&c=7&r=0&o=7&dpr=1.3&pid=1.7&rm=3');
            Image.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(67:7)", "entry");
            Image.width(50);
            Image.height(50);
        }, Image);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('动态加载');
            Text.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(71:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            LoadingProgress.create();
            LoadingProgress.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(72:7)", "entry");
            LoadingProgress.width(50);
            LoadingProgress.color(Color.Blue);
        }, LoadingProgress);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('二维码');
            Text.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(76:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            QRCode.create('吉林大学前卫校区');
            QRCode.debugLine("entry/src/main/ets/pages/a09CommonTest.ets(77:7)", "entry");
        }, QRCode);
        QRCode.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "a09CommonTest";
    }
}
registerNamedRoute(() => new a09CommonTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a09CommonTest", pageFullPath: "entry/src/main/ets/pages/a09CommonTest", integratedHsp: "false", moduleType: "followWithHap" });
