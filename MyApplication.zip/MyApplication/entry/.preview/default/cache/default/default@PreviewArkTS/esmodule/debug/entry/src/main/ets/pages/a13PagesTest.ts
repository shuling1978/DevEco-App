if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface a13PagesTest_Params {
}
class a13PagesTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: a13PagesTest_Params) {
    }
    updateStateVars(params: a13PagesTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/a13PagesTest.ets(6:5)", "entry");
            Column.width('100%');
            Column.height('100%');
            Column.backgroundColor('#f0eff4');
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/a13PagesTest.ets(7:7)", "entry");
            Row.width('92%');
            Row.height(60);
            Row.margin({ top: 5 });
            Row.backgroundColor(Color.White);
            Row.borderRadius(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('头部区域');
            Text.debugLine("entry/src/main/ets/pages/a13PagesTest.ets(8:9)", "entry");
        }, Text);
        Text.pop();
        Row.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create();
            List.debugLine("entry/src/main/ets/pages/a13PagesTest.ets(16:7)", "entry");
            List.margin({ top: 10 });
            List.width('92%');
            List.layoutWeight(1);
            List.backgroundColor(Color.White);
        }, List);
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, true);
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.debugLine("entry/src/main/ets/pages/a13PagesTest.ets(17:9)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('list区域');
                    Text.debugLine("entry/src/main/ets/pages/a13PagesTest.ets(18:11)", "entry");
                }, Text);
                Text.pop();
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            ListItem.pop();
        }
        List.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/a13PagesTest.ets(27:7)", "entry");
            Row.width('92%');
            Row.height(60);
            Row.margin({ top: 5 });
            Row.backgroundColor(Color.White);
            Row.borderRadius(10);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('导航区域');
            Text.debugLine("entry/src/main/ets/pages/a13PagesTest.ets(28:9)", "entry");
        }, Text);
        Text.pop();
        Row.pop();
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "a13PagesTest";
    }
}
registerNamedRoute(() => new a13PagesTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a13PagesTest", pageFullPath: "entry/src/main/ets/pages/a13PagesTest", integratedHsp: "false", moduleType: "followWithHap" });
