if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface Method3_Params {
}
interface Method2_Params {
}
interface Method_Params {
}
class Method extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Method_Params) {
    }
    updateStateVars(params: Method_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //文本显示
            Text.create('吉林大学');
            Text.debugLine("entry/src/main/ets/pages/Method.ets(7:5)", "entry");
            //文本显示
            Text.fontColor(Color.Blue);
            //文本显示
            Text.fontSize(50);
            //文本显示
            Text.onClick(() => {
                //逻辑
            });
        }, Text);
        //文本显示
        Text.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
class Method2 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Method2_Params) {
    }
    updateStateVars(params: Method2_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //页面被构建前 拿取数据
    aboutToAppear(): void {
        //逻辑
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //必须有且仅有一个根节点，也就是最外层包裹盒子
            //Column列容器
            Column.create();
            Column.debugLine("entry/src/main/ets/pages/Method.ets(34:5)", "entry");
        }, Column);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create('Entry');
            Text.debugLine("entry/src/main/ets/pages/Method.ets(36:7)", "entry");
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //系统组件
            Text.create('吉林大学前卫校区');
            Text.debugLine("entry/src/main/ets/pages/Method.ets(38:7)", "entry");
            //系统组件
            Text.fontColor(Color.Red);
        }, Text);
        //系统组件
        Text.pop();
        {
            this.observeComponentCreation2((elmtId, isInitialRender) => {
                if (isInitialRender) {
                    let componentCall = new 
                    //自定义组件
                    Method3(this, {}, undefined, elmtId, () => { }, { page: "entry/src/main/ets/pages/Method.ets", line: 41, col: 7 });
                    ViewPU.create(componentCall);
                    let paramsLambda = () => {
                        return {};
                    };
                    componentCall.paramsGenerator_ = paramsLambda;
                }
                else {
                    this.updateStateVarsOfChildByElmtId(elmtId, {});
                }
            }, { name: "Method3" });
        }
        //必须有且仅有一个根节点，也就是最外层包裹盒子
        //Column列容器
        Column.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "Method2";
    }
}
class Method3 extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: Method3_Params) {
    }
    updateStateVars(params: Method3_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/Method.ets(51:5)", "entry");
        }, Text);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('吉林大学');
            Span.debugLine("entry/src/main/ets/pages/Method.ets(52:7)", "entry");
        }, Span);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('前卫');
            Span.debugLine("entry/src/main/ets/pages/Method.ets(53:7)", "entry");
            Span.fontColor(Color.Red);
        }, Span);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Span.create('校区');
            Span.debugLine("entry/src/main/ets/pages/Method.ets(55:7)", "entry");
        }, Span);
        Text.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
}
registerNamedRoute(() => new Method2(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Method", pageFullPath: "entry/src/main/ets/pages/Method", integratedHsp: "false", moduleType: "followWithHap" });
