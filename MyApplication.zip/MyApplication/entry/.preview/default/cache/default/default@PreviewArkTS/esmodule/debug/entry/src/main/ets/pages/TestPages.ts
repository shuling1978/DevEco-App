if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface TestPages_Params {
    str?: string;
    age?: number;
}
//let num : number = 0
//let用于全局，全局这么写
//let用于声明局部变量
enum ColorSet {
    white = "1",
    black = "2"
}
let color: ColorSet = ColorSet.black;
//联合类型
let luckyNum: number | string | boolean | ColorSet = ColorSet.black;
luckyNum = false;
//之前的方式声明函数
function submit1() {
    //逻辑
    if (true) {
    }
}
//箭头函数，lambda表达式
//没有名字，不能重复使用
() => {
    //逻辑
};
//声明类
class User {
    name: string = '张三';
    age: number = 20;
}
const user = new User();
luckyNum = user.name;
//接口
interface userType {
    name: string;
    age: number;
    email?: string;
}
let userData: userType = { name: '张三', age: 20, email: '1@qq.com' };
let userArray: userType[] = [
    { name: '1', age: 2 },
    { name: '1', age: 3 }
];
class TestPages extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__str = new ObservedPropertySimplePU('qwer', this, "str");
        this.__age = new ObservedPropertySimplePU(20
        //鸿蒙当中怎么声明函数
        , this, "age");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: TestPages_Params) {
        if (params.str !== undefined) {
            this.str = params.str;
        }
        if (params.age !== undefined) {
            this.age = params.age;
        }
    }
    updateStateVars(params: TestPages_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__str.purgeDependencyOnElmtId(rmElmtId);
        this.__age.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__str.aboutToBeDeleted();
        this.__age.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //中间用来定义数据，声明函数
    //鸿蒙当中怎么定义数据
    private __str: ObservedPropertySimplePU<string>;
    get str() {
        return this.__str.get();
    }
    set str(newValue: string) {
        this.__str.set(newValue);
    }
    private __age: ObservedPropertySimplePU<number>;
    get age() {
        return this.__age.get();
    }
    set age(newValue: number) {
        this.__age.set(newValue);
    }
    //鸿蒙当中怎么声明函数
    submitFun() {
        if (true) {
            //调用页面内部状态
            this.age = 30;
            luckyNum = 20;
        }
    }
    //构造函数，怎么构建页面
    initialRender() {
        //build中写UI描述，页面信息
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "TestPages";
    }
}
registerNamedRoute(() => new TestPages(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/TestPages", pageFullPath: "entry/src/main/ets/pages/TestPages", integratedHsp: "false", moduleType: "followWithHap" });
