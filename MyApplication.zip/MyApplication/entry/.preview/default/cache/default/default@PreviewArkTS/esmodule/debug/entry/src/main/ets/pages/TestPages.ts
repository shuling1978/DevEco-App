if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface TestPages_Params {
    str?: string;
}
class TestPages extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__str = new ObservedPropertySimplePU('qwer'
        //中间用来定义数据，声明函数
        //构造函数，怎么构建页面
        , this, "str");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: TestPages_Params) {
        if (params.str !== undefined) {
            this.str = params.str;
        }
    }
    updateStateVars(params: TestPages_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__str.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__str.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    //鸿蒙当中怎么定义数据
    private __str: ObservedPropertySimplePU<string>;
    get str() {
        return this.__str.get();
    }
    set str(newValue: string) {
        this.__str.set(newValue);
    }
    //中间用来定义数据，声明函数
    //构造函数，怎么构建页面
    initialRender() {
        //build中写UI描述，页面信息
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "TestPages";
    }
}
registerNamedRoute(() => new TestPages(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/TestPages", pageFullPath: "entry/src/main/ets/pages/TestPages", integratedHsp: "false", moduleType: "followWithHap" });
