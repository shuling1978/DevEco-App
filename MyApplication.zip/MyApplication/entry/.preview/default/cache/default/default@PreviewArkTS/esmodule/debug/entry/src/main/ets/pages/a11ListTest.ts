if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface a11ListTest_Params {
    messageList?: message[];
}
interface message {
    imgUrl: string | Resource;
    name: string;
    messageData: string;
}
export class a11ListTest extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.__messageList = new ObservedPropertyObjectPU([
            { imgUrl: 'https://pic.nximg.cn/file/20240317/28864261_235825728127_2.jpg', name: '猫猫', messageData: '[30条]小橘：你好' },
            { imgUrl: 'https://pic.nximg.cn/file/20240317/28864261_235825728127_2.jpg', name: '猫猫', messageData: '[30条]小橘：你好' },
            { imgUrl: 'https://pic.nximg.cn/file/20240317/28864261_235825728127_2.jpg', name: '猫猫', messageData: '[30条]小橘：你好' },
            { imgUrl: 'https://pic.nximg.cn/file/20240317/28864261_235825728127_2.jpg', name: '猫猫', messageData: '[30条]小橘：你好' },
            { imgUrl: 'https://pic.nximg.cn/file/20240317/28864261_235825728127_2.jpg', name: '猫猫', messageData: '[30条]小橘：你好' },
            { imgUrl: 'https://pic.nximg.cn/file/20240317/28864261_235825728127_2.jpg', name: '猫猫', messageData: '[30条]小橘：你好' },
            { imgUrl: 'https://pic.nximg.cn/file/20240317/28864261_235825728127_2.jpg', name: '猫猫', messageData: '[30条]小橘：你好' },
            { imgUrl: 'https://pic.nximg.cn/file/20240317/28864261_235825728127_2.jpg', name: '猫猫', messageData: '[30条]小橘：你好' },
            { imgUrl: 'https://pic.nximg.cn/file/20240317/28864261_235825728127_2.jpg', name: '猫猫', messageData: '[30条]小橘：你好' },
            { imgUrl: 'https://pic.nximg.cn/file/20240317/28864261_235825728127_2.jpg', name: '猫猫', messageData: '[30条]小橘：你好' },
            { imgUrl: 'https://pic.nximg.cn/file/20240317/28864261_235825728127_2.jpg', name: '猫猫', messageData: '[30条]小橘：你好' },
            { imgUrl: 'https://pic.nximg.cn/file/20240317/28864261_235825728127_2.jpg', name: '猫猫', messageData: '[30条]小橘：你好' }
        ], this, "messageList");
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: a11ListTest_Params) {
        if (params.messageList !== undefined) {
            this.messageList = params.messageList;
        }
    }
    updateStateVars(params: a11ListTest_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
        this.__messageList.purgeDependencyOnElmtId(rmElmtId);
    }
    aboutToBeDeleted() {
        this.__messageList.aboutToBeDeleted();
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    private __messageList: ObservedPropertyObjectPU<message[]>;
    get messageList() {
        return this.__messageList.get();
    }
    set messageList(newValue: message[]) {
        this.__messageList.set(newValue);
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            List.create();
            List.debugLine("entry/src/main/ets/pages/a11ListTest.ets(28:5)", "entry");
            List.width('100%');
            List.height('100%');
            List.border({ width: 2 });
        }, List);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            ForEach.create();
            const forEachItemGenFunction = _item => {
                const item = _item;
                {
                    const itemCreation = (elmtId, isInitialRender) => {
                        ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                        ListItem.create(deepRenderFunction, true);
                        if (!isInitialRender) {
                            //ui组件
                            ListItem.pop();
                        }
                        ViewStackProcessor.StopGetAccessRecording();
                    };
                    const itemCreation2 = (elmtId, isInitialRender) => {
                        ListItem.create(deepRenderFunction, true);
                        //ui组件
                        ListItem.border({ width: 2 });
                        //ui组件
                        ListItem.width('100%');
                        ListItem.debugLine("entry/src/main/ets/pages/a11ListTest.ets(32:9)", "entry");
                    };
                    const deepRenderFunction = (elmtId, isInitialRender) => {
                        itemCreation(elmtId, isInitialRender);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Row.create();
                            Row.debugLine("entry/src/main/ets/pages/a11ListTest.ets(33:11)", "entry");
                            Row.padding(5);
                            Row.width('100%');
                        }, Row);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Image.create(item.imgUrl);
                            Image.debugLine("entry/src/main/ets/pages/a11ListTest.ets(34:13)", "entry");
                            Image.width(40);
                            Image.margin({ right: 3 });
                        }, Image);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Column.create();
                            Column.debugLine("entry/src/main/ets/pages/a11ListTest.ets(37:13)", "entry");
                            Column.alignItems(HorizontalAlign.Start);
                            Column.border({ width: { bottom: 1 } });
                        }, Column);
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.name);
                            Text.debugLine("entry/src/main/ets/pages/a11ListTest.ets(38:15)", "entry");
                        }, Text);
                        Text.pop();
                        this.observeComponentCreation2((elmtId, isInitialRender) => {
                            Text.create(item.messageData);
                            Text.debugLine("entry/src/main/ets/pages/a11ListTest.ets(39:15)", "entry");
                        }, Text);
                        Text.pop();
                        Column.pop();
                        Row.pop();
                        //ui组件
                        ListItem.pop();
                    };
                    this.observeComponentCreation2(itemCreation2, ListItem);
                    //ui组件
                    ListItem.pop();
                }
            };
            this.forEachUpdateFunction(elmtId, this.messageList, forEachItemGenFunction);
        }, ForEach);
        ForEach.pop();
        {
            const itemCreation = (elmtId, isInitialRender) => {
                ViewStackProcessor.StartGetAccessRecordingFor(elmtId);
                ListItem.create(deepRenderFunction, true);
                if (!isInitialRender) {
                    ListItem.pop();
                }
                ViewStackProcessor.StopGetAccessRecording();
            };
            const itemCreation2 = (elmtId, isInitialRender) => {
                ListItem.create(deepRenderFunction, true);
                ListItem.border({ width: 2 });
                ListItem.debugLine("entry/src/main/ets/pages/a11ListTest.ets(53:7)", "entry");
            };
            const deepRenderFunction = (elmtId, isInitialRender) => {
                itemCreation(elmtId, isInitialRender);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('2');
                    Text.debugLine("entry/src/main/ets/pages/a11ListTest.ets(54:9)", "entry");
                }, Text);
                Text.pop();
                ListItem.pop();
            };
            this.observeComponentCreation2(itemCreation2, ListItem);
            ListItem.pop();
        }
        List.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "a11ListTest";
    }
}
registerNamedRoute(() => new a11ListTest(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a11ListTest", pageFullPath: "entry/src/main/ets/pages/a11ListTest", integratedHsp: "false", moduleType: "followWithHap" });
