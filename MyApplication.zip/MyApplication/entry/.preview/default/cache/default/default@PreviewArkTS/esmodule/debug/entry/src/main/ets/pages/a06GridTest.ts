if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface a06Grid_Params {
}
class a06Grid extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: a06Grid_Params) {
    }
    updateStateVars(params: a06Grid_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //Grid中子元素只能是GridItem
            Grid.create();
            Grid.debugLine("entry/src/main/ets/pages/a06GridTest.ets(8:5)", "entry");
            //Grid中子元素只能是GridItem
            Grid.width(300);
            //Grid中子元素只能是GridItem
            Grid.height(300);
            //Grid中子元素只能是GridItem
            Grid.border({ width: 5 });
            //Grid中子元素只能是GridItem
            Grid.columnsTemplate('1fr 1fr 3fr');
        }, Grid);
        {
            const itemCreation2 = (elmtId, isInitialRender) => {
                GridItem.create(() => { }, false);
                GridItem.debugLine("entry/src/main/ets/pages/a06GridTest.ets(9:7)", "entry");
            };
            const observedDeepRender = () => {
                this.observeComponentCreation2(itemCreation2, GridItem);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Flex.create();
                    Flex.debugLine("entry/src/main/ets/pages/a06GridTest.ets(10:9)", "entry");
                    Flex.border({ width: 2 });
                }, Flex);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('1');
                    Text.debugLine("entry/src/main/ets/pages/a06GridTest.ets(11:11)", "entry");
                }, Text);
                Text.pop();
                Flex.pop();
                GridItem.pop();
            };
            observedDeepRender();
        }
        {
            const itemCreation2 = (elmtId, isInitialRender) => {
                GridItem.create(() => { }, false);
                GridItem.debugLine("entry/src/main/ets/pages/a06GridTest.ets(14:7)", "entry");
            };
            const observedDeepRender = () => {
                this.observeComponentCreation2(itemCreation2, GridItem);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Flex.create();
                    Flex.debugLine("entry/src/main/ets/pages/a06GridTest.ets(15:9)", "entry");
                    Flex.border({ width: 2 });
                }, Flex);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('2');
                    Text.debugLine("entry/src/main/ets/pages/a06GridTest.ets(16:11)", "entry");
                }, Text);
                Text.pop();
                Flex.pop();
                GridItem.pop();
            };
            observedDeepRender();
        }
        {
            const itemCreation2 = (elmtId, isInitialRender) => {
                GridItem.create(() => { }, false);
                GridItem.debugLine("entry/src/main/ets/pages/a06GridTest.ets(19:7)", "entry");
            };
            const observedDeepRender = () => {
                this.observeComponentCreation2(itemCreation2, GridItem);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Flex.create();
                    Flex.debugLine("entry/src/main/ets/pages/a06GridTest.ets(20:9)", "entry");
                    Flex.border({ width: 2 });
                }, Flex);
                this.observeComponentCreation2((elmtId, isInitialRender) => {
                    Text.create('3');
                    Text.debugLine("entry/src/main/ets/pages/a06GridTest.ets(21:11)", "entry");
                }, Text);
                Text.pop();
                Flex.pop();
                GridItem.pop();
            };
            observedDeepRender();
        }
        //Grid中子元素只能是GridItem
        Grid.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "a06Grid";
    }
}
registerNamedRoute(() => new a06Grid(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/a06GridTest", pageFullPath: "entry/src/main/ets/pages/a06GridTest", integratedHsp: "false", moduleType: "followWithHap" });
