if (!("finalizeConstruction" in ViewPU.prototype)) {
    Reflect.set(ViewPU.prototype, "finalizeConstruction", () => { });
}
interface row_Params {
}
class row extends ViewPU {
    constructor(parent, params, __localStorage, elmtId = -1, paramsLambda = undefined, extraInfo) {
        super(parent, __localStorage, elmtId, extraInfo);
        if (typeof paramsLambda === "function") {
            this.paramsGenerator_ = paramsLambda;
        }
        this.setInitiallyProvidedValue(params);
        this.finalizeConstruction();
    }
    setInitiallyProvidedValue(params: row_Params) {
    }
    updateStateVars(params: row_Params) {
    }
    purgeVariableDependenciesOnElmtId(rmElmtId) {
    }
    aboutToBeDeleted() {
        SubscriberManager.Get().delete(this.id__());
        this.aboutToBeDeletedInternal();
    }
    initialRender() {
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            //行布局
            //主轴为横向 默认侧轴居中
            Row.create();
            Row.debugLine("entry/src/main/ets/pages/Row.ets(8:5)", "entry");
            //行布局
            //主轴为横向 默认侧轴居中
            Row.width('100%');
            //行布局
            //主轴为横向 默认侧轴居中
            Row.height('100%');
            //行布局
            //主轴为横向 默认侧轴居中
            Row.border({ width: 5 });
            //行布局
            //主轴为横向 默认侧轴居中
            Row.justifyContent(FlexAlign.SpaceBetween);
            //行布局
            //主轴为横向 默认侧轴居中
            Row.alignItems(VerticalAlign.Bottom);
        }, Row);
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/Row.ets(9:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/Row.ets(10:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/Row.ets(11:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 10 });
        }, Text);
        Text.pop();
        this.observeComponentCreation2((elmtId, isInitialRender) => {
            Text.create();
            Text.debugLine("entry/src/main/ets/pages/Row.ets(12:7)", "entry");
            Text.width(50);
            Text.height(50);
            Text.border({ width: 10 });
        }, Text);
        Text.pop();
        //行布局
        //主轴为横向 默认侧轴居中
        Row.pop();
    }
    rerender() {
        this.updateDirtyElements();
    }
    static getEntryName(): string {
        return "row";
    }
}
registerNamedRoute(() => new row(undefined, {}), "", { bundleName: "com.example.myapplication", moduleName: "entry", pagePath: "pages/Row", pageFullPath: "entry/src/main/ets/pages/Row", integratedHsp: "false", moduleType: "followWithHap" });
